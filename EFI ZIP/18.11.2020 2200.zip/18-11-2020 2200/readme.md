# Acer Aspire A514-52-37H1 macOS Catalina Clover EFI

#### macOS Catalina Version : 10.15.7
#### Clover Version : v2.5k r5120
#### Special thanks to [Daliansky](https://github.com/daliansky)

## 18-11-2020 2200\
- Added support for Intel AX201 with Airportitlwm.kext}
- VRAM should remain at 1536MB
