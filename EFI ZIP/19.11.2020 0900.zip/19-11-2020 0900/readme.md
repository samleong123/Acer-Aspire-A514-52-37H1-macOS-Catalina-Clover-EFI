# Acer Aspire A514-52-37H1 macOS Catalina Clover EFI

#### macOS Catalina Version : 10.15.7
#### Clover Version : v2.5k r5120
#### Special thanks to [Daliansky](https://github.com/daliansky)

## 19-11-2020 0900
- Added new brightness control
  - Update : 19-11-2020 : This brightness control will conflict with Trackpad SSDT , removed and added another new brightness control patch
- VRAM set to 2048MB
