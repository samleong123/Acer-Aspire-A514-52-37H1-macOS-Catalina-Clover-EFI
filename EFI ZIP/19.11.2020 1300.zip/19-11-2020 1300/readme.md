# Acer Aspire A514-52-37H1 macOS Catalina Clover EFI

#### macOS Catalina Version : 10.15.7
#### Clover Version : v2.5k r5120
#### Special thanks to [Daliansky](https://github.com/daliansky)

## 19-11-2020 1300
- Added support for trackpad (VoodooI2C) with correct hotpatch and SSDT
    - Remove broken brightness control that will conflict with Trackpad SSDT
    - Added new brightness control
- VRAM set to 2048MB
